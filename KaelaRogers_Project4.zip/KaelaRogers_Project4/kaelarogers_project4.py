import tkinter
import random
import time

colors = ['Red','Blue','Green','Pink','Yellow','Orange','White','Purple']
score = 0
timeleft = 30

def startGame(level, start1, start2, start3):
#Starts the game when called a button
        global getScore
        getScore = level
        nextColor()
        instructions2.config(text = "Get " + str(level) + " to win.")
        start1.pack_forget()
        start2.pack_forget()
        start3.pack_forget()
        if timeleft == 30:
                countdown()


def startGame2(event):
#Starts the game when called with the enter key
        nextColor()
        if timeleft == 30:
                countdown()
        

def nextColor():
#Gives the player a point when the answer is correct. Randomizes the list of
#colors and set the word, font color, and background color. Deletes what was typed in
#the entery box. Updates the score."""
        global score
        global timeleft
        
        answer = entry.get().lower()
        
        if answer == colors[1].lower():
                score += 1
                win(timeleft)
                
        entry.delete(0, tkinter.END)
        random.shuffle(colors)
        label.config(fg = str(colors[1]), text = str(colors[0]), bg = str(colors[2]))
        game.configure(bg = str(colors[3]))
        scoreLabel.config(text = "Score: " + str(score))

def timeUp(timeleft):
#If the time left is less than six, it changes the color to red
        if timeleft < 6:
                timeLabel.config(fg="red")

def countdown():
#Counts down the time of the game and displays it. Determines if time is
#zero. Tells the player they ran out of time if the time left is zero.
#Then hides the time and the color word to white so its clear the game it over."""
        global timeleft
        if timeleft > 0:
                timeleft -= 1
                timeUp(timeleft)
                timeLabel.config(text = "Time left: " + str(timeleft))
                timeLabel.after(1000, countdown)
        elif timeleft == 0 and score != getScore:
                lose = tkinter.Label(game, text="You ran out of time!",
                                    fg = "red", bg="black",font = ('futura', 14))
                lose.pack(pady = 10)
                label.config(fg = "white", bg = "black")
                restart()

def win(timeleft):
#Determines if the player has won. Says they win. Hides time.
        if score == getScore:
                win = tkinter.Label(game, text="You win with " + str(timeleft) + " seconds left!",
                                    fg = "white", bg="black",font = ('futura', 14))
                win.pack(pady = 10)
                label.config(fg = "white")
                update()
                restart()

def update():
#Opens file that saves scores. Determines if current time is the fastest.
        global timeleft 
        with open('scores.txt') as file:
                for line in file:
                        prevtime = line.rstrip('\n')

        if timeleft > int(prevtime):
                best()
        else: 
                notbest()

def best():
#If current time is the fastest, updates txt doc and tells the player.
        global timeleft
        besttime = tkinter.Label(game, text= str(timeleft) + " is your best time!",
                                    fg = "white", bg="black",font = ('futura', 14))
        besttime.pack(pady = 10)
        with open('scores.txt', 'a') as file:
                file.write('\n' + str(timeleft))

def notbest():
#Tells the player their current time isn't their fastest.
        notbest = tkinter.Label(game, text= "This wasn't your fastest time.",
                                    fg = "white", bg="black",font = ('futura', 14))
        notbest.pack(pady = 10)

def restart():
#Restarts the game
        global timeleft
        yes = tkinter.Button(game, text = "Restart?", command = lambda : startGame(10, None, None, None))
        yes.pack()
        timeleft = 30
        score = 0

#Game window
game = tkinter.Tk()
game.title("COLOR GAME HARD MODE")
game.geometry("500x500")
game.configure(bg='black')

#Game text & information
name = tkinter.Label(game, text = "COLOR GAME", font = ('futura', 30), bg = "black", fg = "white")
instructions = tkinter.Label(game, text = "Type in the color of the words,\nnot the word text or the background color!",
                             font = ('futura', 14), bg = "black", fg = "white")
instructions2 = tkinter.Label(game,font = ('futura', 14), bg = "black", fg = "white")
timeLabel = tkinter.Label(game, text = "Time left: " +
			str(timeleft), font = ('futura', 14), bg = "black", fg = "white")
scoreLabel = tkinter.Label(game, font = ('futura', 14), bg = "black", fg = "white")

name.pack(pady = 20);
instructions.pack(pady = 5)
instructions2.pack(pady = 5)
scoreLabel.pack(pady = 5)
timeLabel.pack()

#Color words
label = tkinter.Label(game, font = ('Helvetica', 60), bg = "black")
label.pack(pady = 20)

entry = tkinter.Entry(game)
entry.pack(pady = 5)
entry.focus_set()
entry.bind('<Return>', startGame2)

#Entry
start1 = tkinter.Button(game, text = "Easy",
                        command = lambda : startGame(5, start1, start2, start3))
start1.pack(pady = 2)
start2 = tkinter.Button(game, text = "Medium",
                        command = lambda : startGame(10, start1, start2, start3))
start2.pack(pady = 2)
start3 = tkinter.Button(game, text = "Hard",
                        command = lambda : startGame(13, start1, start2, start3))
start3.pack(pady = 2)

game.mainloop()
