Projects
By Kaela Rogers
10.30.2020


Goals: 
>Expand the previous color game. 
>Add different difficulties 
	>Easy, medium, hard
	>Based on how many points are needed to win
>Ability to restart the game
	>Restart button at win and lose screen
	>Timer set to zero, score set to zero, words play


Troubleshooting:
>I had a lot of problems with the entry box. Because I changed the game to start with buttons instead of enter, I had to figure out another way for the box to work. I couldn't figure out how to bind the entry box to a function that had a parameters so I created a new function similar to the startGame function without the parameters (they are only needed in the very start of the game). 
>I wanted to hide the buttons in the beginning so I Googled how to use use parameters with buttons. I added lambda as the command and was able to also add the function and parameters. 
>Score said "Score: " and a number instead of starting at zero. Used the variable getScore, which is used to set the difficulty instead of score.