This program using Pygame to create a simple game where the user plays as an alien and collects the planets on the screen using their mouse or trackpad. Once the player collects all the planets displayed on the screen, they will level up and more planets will be displayed. 

Future Plans: I would like to add enemies to add a bit of difficulty to the game. 