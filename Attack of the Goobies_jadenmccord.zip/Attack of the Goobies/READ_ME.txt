I spent more time on this project than any other project of this course.
I utilized an example code of a generic space shooter on the Python Arcade
website and used arcade to turn it into what it is now. Throughout all of the
work on this game I learned so much about the arcade module, and coding for a
game in general. Although the amount of troubleshooting was nightmarish for
parts, I had a lot of fun with the challenge and loved seeing it finally work
the way I intended. I started by trying to make a platformer where you played
as a little slime, but I didn't want to do the platformer without a detailed
and charismatic player character, so I attempted to create an animated sprite
from a spritesheet. Sadly, I was unable to get the spritesheet to function no
matter how much I researched and tried other methods, so I decided to make a
different game entirely: a space invaders-esque game. Although I used an example
code, I've made DRASTIC changes to the original code, and even added some brand
new content to form identity. Some sounds were created by editing and splicing
sound files together via sound editing software, some sprites are creations made from
editing and combining certain sprites to create new ones, etc. I wanted to make
this game as original as possible with what I know and what I'm given with the
sample code.

CONTROLS
----------------------------
Very simple
Use the mouse to move your spaceship across the bottom of the screen, and click
to fire at the Goobies.

When all Goobies have been killed, you can press the spacebar to spawn a new
batch of them (I don't recommend spawning more until all currently on screen are
gone, the abundance of sprites can cause performance issues).

Finally, for a super secret easter egg, just press the S key. Be warned, it is
not for the faint of heart.
-----------------------------

If you have any feedback, don't hesitate to let me know in the class Discord chat.
Thanks for playing!