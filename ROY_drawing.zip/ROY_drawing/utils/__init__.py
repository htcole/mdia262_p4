from .settings import*
from .button import Button
import pygame
pygame.init()
pygame.font.init()
