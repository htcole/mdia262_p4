Tutorial Source: Tech with Tim: https://youtu.be/N20eXcfyQ_4

I decided since i made a paintbox in my HTML class i would play around with
the idea of attmeping a simailr feat on Pyhton and making it a matching game
that you can play with friends by making your own pitcure and trying to have
someone recreate them.

issues: there were alot of feats with this. I had never used so many files for
a single pyhton program and when a mistake happened, pyhton has a hard time finding
the origin of the error and it sen tme on a wild goose chase many times. i spent
roughly 5 hours on the program despite the tutorial only being an hour long XD.
