I have created a game that is similar to the arcade classic Galactica and Space Invaders.
The player shoots from the bottom of the screen at enemies that bounce from left to right.
Every time the player hits an enemy, they disappear and their score goes up by one.
If the enemy gets to the bottom of the screen, then the game will end and the player will have a final score. 

I had trouble figuring out an idea of what I wanted to do for this project. 
I searched around the Internet for some ideas, and finally decided on doing this game.
I was influenced by Galactica and Space Invaders, yet I wanted to put an original twist on it instead of completely trying to copy it. 

Some issues I ran into while creating this game was mainly by trying to add music to the file.
I tried to use .mp3 files for it, but I ran into errors every time I tried to do this. 
I decided to convert the files into .wav instead, which solved the issue.
I found 